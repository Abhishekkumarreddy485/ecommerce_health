import React from 'react'

export default function Customer() {
  return (
    <div>This is a normal User</div>
  )
}
